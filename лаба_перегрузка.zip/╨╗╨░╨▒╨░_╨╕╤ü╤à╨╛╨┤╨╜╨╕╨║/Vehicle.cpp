#include "Vehicle.h"

std::ostream& operator<<(std::ostream& os, const Vehicle& vehicle) {
    return os << "Model: " << vehicle.model << ", Category: " << vehicle.category;
}
