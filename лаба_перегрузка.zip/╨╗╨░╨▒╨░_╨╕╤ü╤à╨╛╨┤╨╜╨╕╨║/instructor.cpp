#include "Instructor.h"

std::ostream& operator<<(std::ostream& os, const Instructor& instructor) {
    return os << "Instructor: " << instructor.name << ", Age: " << instructor.age 
              << ", Vehicle: " << instructor.vehicle;
}
