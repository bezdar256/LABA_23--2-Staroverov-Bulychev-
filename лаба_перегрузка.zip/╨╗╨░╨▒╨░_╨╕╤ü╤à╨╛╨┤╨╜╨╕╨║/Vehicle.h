#pragma once
#include <iostream>
#include <string>

class Vehicle {
public:
    std::string model;
    std::string category;

    Vehicle(const std::string& model, const std::string& category) 
        : model(model), category(category) {}

    friend std::ostream& operator<<(std::ostream& os, const Vehicle& vehicle);
};
