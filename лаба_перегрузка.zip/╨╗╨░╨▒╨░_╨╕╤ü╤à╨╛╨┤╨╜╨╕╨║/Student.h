#pragma once
#include <iostream>
#include "Location.h" // Убедитесь, что этот класс определен

class Student {
public:
    std::string firstName, lastName, patronymic;
    int age;
    Location location;

    Student(const std::string& firstName, const std::string& lastName, const std::string& patronymic, int age, const Location& location) 
        : firstName(firstName), lastName(lastName), patronymic(patronymic), age(age), location(location) {}

    friend std::ostream& operator<<(std::ostream& os, const Student& student);
};
