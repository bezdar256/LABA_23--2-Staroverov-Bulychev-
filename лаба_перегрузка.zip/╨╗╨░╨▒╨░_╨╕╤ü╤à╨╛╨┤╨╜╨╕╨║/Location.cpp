#include "Location.h"

std::ostream& operator<<(std::ostream& os, const Location& location) {
    return os << location.region << ", " << location.city << ", " 
              << location.district << ", " << location.street;
}
