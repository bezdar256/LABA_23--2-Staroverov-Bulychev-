#include "Student.h"

std::ostream& operator<<(std::ostream& os, const Student& student) {
    return os << "Student: " << student.firstName << " " << student.lastName 
              << " " << student.patronymic << ", Age: " << student.age 
              << ", Location: " << student.location;
}
