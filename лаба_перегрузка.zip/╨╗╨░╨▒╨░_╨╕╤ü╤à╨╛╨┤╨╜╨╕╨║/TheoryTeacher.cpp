#include "TheoryTeacher.h"

std::ostream& operator<<(std::ostream& os, const TheoryTeacher& teacher) {
    return os << "Theory Teacher: " << teacher.name << ", Age: " << teacher.age 
              << ", Subject: " << teacher.subject;
}
