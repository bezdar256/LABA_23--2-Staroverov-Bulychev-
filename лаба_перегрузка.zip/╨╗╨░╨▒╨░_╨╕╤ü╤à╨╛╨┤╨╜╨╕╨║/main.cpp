#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include "Student.h"
#include "Instructor.h"
#include "TheoryTeacher.h"
#include "Vehicle.h"
#include "Location.h"

int main() {
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    Location location("SomeRegion", "SomeCity", "SomeDistrict", "123 Some Street");
    Vehicle vehicle("Toyota Corolla", "B");
    Student student("John", "Doe", "Michael", 20, location);
    Instructor instructor("Jane", 35, vehicle);
    TheoryTeacher teacher("Alex", 40, "Traffic Laws");

    // Демонстрация перегрузки оператора <<
    std::cout << student << std::endl;
    std::cout << instructor << std::endl;
    std::cout << teacher << std::endl;

    return 0;
}
