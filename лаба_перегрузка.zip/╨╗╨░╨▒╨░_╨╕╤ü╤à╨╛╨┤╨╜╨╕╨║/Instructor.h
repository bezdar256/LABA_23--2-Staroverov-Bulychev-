#pragma once
#include <iostream>
#include "Vehicle.h" // Убедитесь, что этот класс определен

class Instructor {
public:
    std::string name;
    int age;
    Vehicle vehicle;

    Instructor(const std::string& name, int age, const Vehicle& vehicle) 
        : name(name), age(age), vehicle(vehicle) {}

    friend std::ostream& operator<<(std::ostream& os, const Instructor& instructor);
};
