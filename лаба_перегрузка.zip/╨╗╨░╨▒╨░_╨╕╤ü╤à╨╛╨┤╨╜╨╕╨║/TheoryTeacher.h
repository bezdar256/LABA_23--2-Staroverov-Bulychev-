#pragma once
#include <iostream>
#include <string>

class TheoryTeacher {
public:
    std::string name;
    int age;
    std::string subject;

    TheoryTeacher(const std::string& name, int age, const std::string& subject)
        : name(name), age(age), subject(subject) {}

    friend std::ostream& operator<<(std::ostream& os, const TheoryTeacher& teacher);
};
